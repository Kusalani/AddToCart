package com.example.onlinehardwarestore.adapters;

import android.content.Context;

public class Glide {
    public static System with(Context context) {
        return null;
    }
}
